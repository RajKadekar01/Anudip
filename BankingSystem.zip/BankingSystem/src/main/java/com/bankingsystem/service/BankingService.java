package com.bankingsystem.service;

import com.bankingsystem.model.Account;
import com.bankingsystem.model.Transaction;
import com.bankingsystem.repository.AccountRepository;
import com.bankingsystem.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class BankingService {

    @Autowired
    private AccountRepository accountRepo;

    @Autowired
    private TransactionRepository transactionRepo;

    public String deposit(Long accountId, double amount) {
        Account account = accountRepo.findById(accountId).orElseThrow(() -> new RuntimeException("Account not found"));
        account.setBalance(account.getBalance() + amount);
        accountRepo.save(account);

        Transaction tx = new Transaction();
        tx.setAccount(account);
        tx.setAmount(amount);
        tx.setType("deposit");
        tx.setDate(new Date());
        transactionRepo.save(tx);

        return "Deposit successful";
    }

    public String withdraw(Long accountId, double amount) {
        Account account = accountRepo.findById(accountId).orElseThrow(() -> new RuntimeException("Account not found"));

        if (account.getBalance() < amount) {
            return "Insufficient funds";
        }

        account.setBalance(account.getBalance() - amount);
        accountRepo.save(account);

        Transaction tx = new Transaction();
        tx.setAccount(account);
        tx.setAmount(amount);
        tx.setType("withdraw");
        tx.setDate(new Date());
        transactionRepo.save(tx);

        return "Withdrawal successful";
    }
}
